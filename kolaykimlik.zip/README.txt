=== T.C Kimlik & Vergi No Dogrulama - Kolay Kimlik Doğrulama ===
Contributors: ftpyz,gurmehub
Tags: tc,vergino,kimlik
Requires at least: 5.9
Tested up to: 5.9
Stable Tag: 1.3.2
Requires PHP: 8.0
License: GPL

TC kimlik onayı ve Vergi Numarası onayı ile kullanıcı kayıtları, ödeme işlemleri ve çeşitli form eklentileri (Contact Form, NinjaForms, WPForms) kullanarak özelleştirilmiş formlar oluşturmaları için geliştirilmiştir.

== Description ==
TC kimlik onayı ve Vergi Numarası onayı ile kullanıcı kayıtları, ödeme işlemleri ve çeşitli form eklentileri (Contact Form, NinjaForms, WPForms) kullanarak özelleştirilmiş formlar oluşturmaları için geliştirilmiştir.

TC kimlik veya Vergi Numarası ile kayıt işlemi gerçekleştirmek, özellikle e-ticaret siteleri için oldukça önemli bir sorumluluktur.

nvi.gov.tr‘nin (Nüfus ve Vatandaşlık İşleri Genel Müdürlüğü) sağladığı API destekleri ile çalışan kolay kimlik , oldukça hızlı ve %100 doğruluk garantisi vermektedir.

Bunlara ek olarak sadece TC Kimlik numarasını matematiksel işlemler ile kontrolünü gerçekleştirerek daha fazla güvenlik sağlayabilirsiniz.

== Frequently Asked Questions ==
Bu Eklentiyi Kullanarak Fatura Kesmek İçin Gerekli Bilgileri Alabilir Miyim?

Evet fatura kesmek için ihtiyacınız olan Vergi Numarası yada T.C Kimlik bilgilerini alabilir. Panelden WooCommerce> Sipariş içinden bu bilgilere ulaşabilirsiniz.
